# Payment configuration
This project does not process real-money deposits, withdrawals, or cash-out. Do not put secret payment keys in Vite/frontend environment variables. If a lawful payment flow is later added, use an authorized provider with a server-side backend, webhook verification, fraud controls, and applicable compliance requirements.
