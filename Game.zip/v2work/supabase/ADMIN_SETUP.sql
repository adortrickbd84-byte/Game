-- After creating your first account in the app, replace USER_UUID below with that user's UUID.
insert into public.admin_roles(user_id,role) values('USER_UUID','admin') on conflict(user_id) do update set role='admin';
