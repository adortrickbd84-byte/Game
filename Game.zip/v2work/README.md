# GameZone Production Virtual-Coin Platform

A real React + Supabase web application (not demo/local-state): authentication, persistent profiles, virtual wallet, transaction history, daily coin claim, admin authorization, database-backed game CRUD, user/KYC status management, site settings, and embedded game URLs.

## Setup
1. Create a Supabase project.
2. Run both SQL migrations in `supabase/migrations/` in order.
3. Register a user through the site.
4. Promote that user's UUID to admin by inserting it into `admin_roles` from the Supabase SQL editor.
5. Copy `.env.example` to `.env` and fill `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
6. Run `npm install`, then `npm run dev`.
7. For hosting, run `npm run build` and publish the `dist/` folder on a static host.

## Admin
Open `/admin/login` and sign in with an account whose UUID exists in `admin_roles` with role `admin`.

## Games
Admins add games from `/admin/games`. Each game uses an HTTPS `play_url`; the player page embeds that URL in a sandboxed iframe.

## Wallet
Coins and points are persistent database values. The daily claim is enforced server-side by a Postgres function and transaction record. Virtual coins have no cash value and there is no cash-out feature.

## KYC / age
The profile includes date of birth, age confirmation, and KYC status fields. These are workflow fields, not an identity-verification provider. A real KYC provider must be integrated separately if legally required.

## Payments
No real-money deposit/withdrawal or cash-out is included. Payment provider credentials should never be placed in frontend code. Use an authorized provider and server-side integration if your legal/business setup permits it.
